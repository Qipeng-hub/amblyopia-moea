#!/bin/bash
# Full pipeline. Usage: bash run_all.sh <root> [n_jobs]
# <root> must contain raw/<STUDY>/extracted/ (see README.md). All outputs are written below <root>.
set -euo pipefail
ROOT=${1:?usage: bash run_all.sh <root> [n_jobs]}; NJ=${2:-32}
SRC=$(cd "$(dirname "$0")/src" && pwd)
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 TSTAR=win12

# 1-2. data harmonisation
python "$SRC/harmonize_aux.py" "$ROOT"
python "$SRC/build_trajectories.py" "$ROOT"

# 3. trajectory model (RQ1): full data + leave-one-trial-out folds, then main-trials-only fits for the sensitivity analysis
for f in ALL ATS5 ATS13 ATS15 ATS16; do python "$SRC/fit_trajectory_model.py" "$ROOT" $f 2000 2000 4; done
python "$SRC/fit_trajectory_model.py" "$ROOT" SUMMARY
for f in ALL ATS5 ATS13 ATS15 ATS16; do NOAUX=1 python "$SRC/fit_trajectory_model.py" "$ROOT" $f 2000 2000 4; done

# 4. static schedules (RQ2, RQ3: NSGA-II, NSGA-III, SMS-EMOA, random search; treatment strata)
python "$SRC/optimize_static.py" "$ROOT" "$NJ" 60000 30 20000 200
python "$SRC/check_simulator.py" "$ROOT" 20000

# 5. six further MOEAs (RQ3)
python "$SRC/compare_algorithms.py" "$ROOT" "$NJ" 60000 30 20000 200

# 6. adaptive schedules (RQ4)
python "$SRC/optimize_adaptive.py" "$ROOT" "$NJ" 60000 30 20000 200

# 7. sensitivity analyses and model-free replay
python "$SRC/sensitivity_and_replay.py" "$ROOT" "$NJ" 60000 10 20000 100

# 8. figures
python "$SRC/figure_1_workflow.py" "$ROOT/results/figures"
python "$SRC/figures_2_4_5.py" "$ROOT"
python "$SRC/figure_3_front.py" "$ROOT"
