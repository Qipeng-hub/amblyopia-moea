"""Figure style: Times New Roman for all text, STIX (Times-compatible) for math.
Times New Roman TTF files placed in <repository>/fonts/ are registered on import; otherwise an installed system copy is used."""
import os, glob
from matplotlib import font_manager as fm, rcParams

for f in glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts", "times*.ttf")):
    fm.fontManager.addfont(f)

def apply(size):
    rcParams.update({"font.family": "Times New Roman", "mathtext.fontset": "stix", "font.size": size,
                     "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300})
