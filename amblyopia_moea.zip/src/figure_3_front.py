"""Figure 3: merged NSGA-II archive for the full-data model (training cohort). usage: python figure_3_front.py <root>"""
import os, sys, pickle
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = sys.argv[1].rstrip("/") + "/"
sys.argv = [sys.argv[0], ROOT, "1", "1", "1", "20000", "200"]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import optimize_static as E
import plot_style; plot_style.apply(10)
FIG = ROOT + "results/figures/"; os.makedirs(FIG, exist_ok=True)

f = np.load(E.OUT + "front_all_ALL.npz"); X, F = f["X"], f["F"]
prim = pickle.load(open(E.OUT + "results.pkl", "rb")); s = prim["sel"][("all", "ALL")]
C = E.train_cohort("all", "ALL")
fixed = np.array([[d] * 6 + [1, 2, 0] for d in range(2, 17)], float); Ff = E.evaluate(fixed, C)
fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
for a, (j, lab) in zip(ax, ((1, "plateau-detection delay (weeks)"), (2, "premature-stop rate"))):
    ok = F[:, 0] <= 10
    sc = a.scatter(F[ok, 0], F[ok, j], c=F[ok, 3 - j], s=4, cmap="viridis", alpha=.6)
    a.plot(Ff[:, 0], Ff[:, j], "o-", color="grey", ms=3, lw=.8, label="fixed interval, L=1, m=2 (2–16 wk)")
    a.plot(*s["cmp_train"][[0, j]], "s", color="k", ms=7, label="comparator (every 5 wk)")
    a.plot(*s["train"][[0, j]], "*", color="red", ms=12, label="selected")
    a.set_xlabel("mean number of visits"); a.set_ylabel(lab)
    cb = fig.colorbar(sc, ax=a); cb.set_label("premature-stop rate" if j == 1 else "delay (weeks)")
ax[0].legend(frameon=False, fontsize=7)
fig.tight_layout(); fig.savefig(FIG + "fig3_front.png"); plt.close(fig)
print("figure written to", FIG)
