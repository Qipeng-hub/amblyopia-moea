"""Figures 2, 4 and 5. usage: python figures_2_4_5.py <root>"""
import os, sys, pickle
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
ROOT = sys.argv[1].rstrip("/") + "/"
sys.argv = [sys.argv[0], ROOT, "1", "1", "1", "20000", "200"]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import optimize_static as E
import plot_style; plot_style.apply(8)
FIG = ROOT + "results/figures/"; os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({
    "axes.linewidth": .6, "xtick.major.width": .6, "ytick.major.width": .6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5, "axes.labelsize": 8.5, "axes.titlesize": 9,
    "legend.fontsize": 7.5, "axes.edgecolor": "#333333", "xtick.color": "#333333", "ytick.color": "#333333",
    "axes.labelcolor": "#222222", "savefig.bbox": "tight", "savefig.pad_inches": .03})
GRID = dict(color="#e6e6e6", lw=.5, zorder=0)
COL = {"spectacles": "#2b6cb0", "patching": "#c0392b", "atropine": "#2f8f5b"}

def tag(a, s, x=-0.02, y=1.02):
    a.text(x, y, s, transform=a.transAxes, fontsize=10, fontweight="bold", va="bottom", ha="right")

def save(fig, name):
    fig.savefig(FIG + name + ".png", dpi=600); fig.savefig(FIG + name + ".pdf"); plt.close(fig)

# ======================= Figure 2 =======================
T = pd.read_csv(ROOT + "derived/traj.csv"); P = pd.read_csv(ROOT + "derived/pts.csv")
D = E.draws("ALL")
fig = plt.figure(figsize=(7.2, 4.0))
gs = GridSpec(2, 4, figure=fig, wspace=.32, hspace=.42, width_ratios=[1, 1, .08, 1.55])
pan = [fig.add_subplot(gs[0, 0])]
pan += [fig.add_subplot(gs[0, 1], sharey=pan[0]), fig.add_subplot(gs[1, 0], sharey=pan[0]), fig.add_subplot(gs[1, 1], sharey=pan[0])]
rng = np.random.default_rng(0)
for k, (a, (tr, tx)) in enumerate(zip(pan, (("ATS5", "spectacles"), ("ATS13", "spectacles"), ("ATS15", "patching"), ("ATS16", "atropine")))):
    ids_all = P[P.trial == tr].pid.values; ids = rng.choice(ids_all, min(40, len(ids_all)), replace=False)
    for i in ids:
        g = T[(T.trial == tr) & (T.pid == i)].sort_values("wk")
        a.plot(g.wk, g.va, color=COL[tx], alpha=.28, lw=.6, solid_capstyle="round", zorder=2)
        a.plot(g.wk.iloc[-1], g.va.iloc[-1], "o", ms=1.6, color=COL[tx], alpha=.55, mec="none", zorder=3)
    a.set_xlim(0, 52); a.set_xticks([0, 13, 26, 39, 52]); a.set_ylim(1.45, -0.1)
    a.set_yticks([0, .3, .6, .9, 1.2]); a.grid(**GRID)
    a.set_title(f"{tr} · {tx}", loc="left", fontsize=8.5, color="#222222")
    a.text(.97, .04, f"40 of {len(ids_all)} children", transform=a.transAxes, ha="right", va="bottom", fontsize=6.8, color="#666666")
    tag(a, "abcd"[k], x=-.12)
    if k in (0, 2): a.set_ylabel("VA (logMAR)")
    else: plt.setp(a.get_yticklabels(), visible=False)
    if k >= 2: a.set_xlabel("weeks since start of treatment")
a = fig.add_subplot(gs[:, 3]); t = np.linspace(0, 52, 300)
for tx, txv in (("spectacles", [0, 0]), ("patching", [1, 0]), ("atropine", [0, 1])):
    txv = np.array(txv, float)
    G = D["muG"] + D["bG"] @ txv; lt = D["muT"] + D["bT"] @ txv
    curves = 0.6 - G[:, None] * (1 - np.exp(-t[None, :] / np.exp(lt)[:, None]))
    m, lo, hi = np.median(curves, 0), np.percentile(curves, 5, 0), np.percentile(curves, 95, 0)
    tau = np.exp(np.median(lt))
    a.fill_between(t, lo, hi, color=COL[tx], alpha=.14, lw=0, zorder=2)
    a.plot(t, m, color=COL[tx], lw=1.6, zorder=3, label=f"{tx} ($\\tau$ ≈ {tau:.0f} wk)")
    a.plot(tau, np.interp(tau, t, m), "o", ms=3.5, color="white", mec=COL[tx], mew=1.1, zorder=4)
a.set_xlim(0, 52); a.set_xticks([0, 13, 26, 39, 52]); a.set_ylim(.64, .12); a.grid(**GRID)
a.set_xlabel("weeks since start of treatment"); a.set_ylabel("VA (logMAR)")
a.set_title("Model: typical child, baseline VA 0.6", loc="left", fontsize=8.5, color="#222222")
a.legend(frameon=False, loc="lower right", handlelength=1.6, borderaxespad=.6)
a.annotate("better", xy=(1.035, .9), xytext=(1.035, .62), xycoords="axes fraction",
           arrowprops=dict(arrowstyle="-|>", lw=.6, color="#666666"), fontsize=6.8, color="#666666", ha="center", rotation=90)
a.text(.97, .29, "line: posterior median\nband: 90% credible interval\n○ : time constant $\\tau$", transform=a.transAxes, ha="right", va="bottom", fontsize=6.6, color="#555555", linespacing=1.3)
tag(a, "e", x=-.09)
save(fig, "fig2_trajectories")

# ======================= Figure 4 =======================
prim = pickle.load(open(E.OUT + "results.pkl", "rb")); res = prim["res"]
SNAME = {"all": "All children (primary)", "spec": "Spectacles stratum", "amb": "Patching / atropine stratum"}
SCOL = {"all": "#2b6cb0", "spec": "#5b8fc7", "amb": "#c0392b"}
rows = []  # (stratum, label, mean, lo, hi, pooled)
for st in ("all", "spec", "amb"):
    fs = [fo for fo in E.FOLDS[st] if fo != "ALL"]
    for fo in fs:
        d = res[(st, fo)]["selected"][:, :3] - res[(st, fo)]["comparator"][:, :3]
        rows.append((st, fo, d.mean(0), np.percentile(d, 2.5, 0), np.percentile(d, 97.5, 0), False))
    w = np.array([len(E.test_cov(fo)) for fo in fs], float); w /= w.sum()
    d = sum(w[i] * (res[(st, fo)]["selected"][:, :3] - res[(st, fo)]["comparator"][:, :3]) for i, fo in enumerate(fs))
    rows.append((st, "Pooled", d.mean(0), np.percentile(d, 2.5, 0), np.percentile(d, 97.5, 0), True))
# y positions with a header line per stratum
ypos, heads, y = [], [], 0.
for st in ("all", "spec", "amb"):
    heads.append((st, y)); y += 1
    for r in rows:
        if r[0] == st: ypos.append(y); y += 1
    y += .45
ytot = y
fig, ax = plt.subplots(1, 3, figsize=(7.2, 3.9), sharey=True, gridspec_kw=dict(wspace=.08, width_ratios=[1, 1.15, 1.15]))
spec = (("Δ visits per child", 0, None, (-3.0, .3)), ("Δ plateau-detection delay (weeks)", 1, 2.0, (-3.2, 2.6)),
        ("Δ premature-stop rate (percentage points)", 2, 3.0, (-2.6, 4.0)))
for a, (lab, k, marg, xl) in zip(ax, spec):
    sc = 100 if k == 2 else 1
    for st, y0 in heads:
        ys = [yy for yy, r in zip(ypos, rows) if r[0] == st]
        a.axhspan(y0 - .5, max(ys) + .5, color="#f4f6f9" if st != "amb" else "#fbf3f2", zorder=0, lw=0)
    for yy, r in zip(ypos, rows):
        m, lo, hi = r[2][k] * sc, r[3][k] * sc, r[4][k] * sc; c = SCOL[r[0]]
        if r[5]:
            a.plot([lo, hi], [yy, yy], color="#111111", lw=1.3, zorder=3, solid_capstyle="butt")
            a.plot(m, yy, "D", ms=5, color="#111111", mec="white", mew=.5, zorder=4)
        else:
            a.plot([lo, hi], [yy, yy], color=c, lw=1.0, zorder=3, solid_capstyle="butt")
            a.plot(m, yy, "o", ms=3.8, color=c, mec="white", mew=.5, zorder=4)
    a.axvline(0, color="#777777", lw=.7, zorder=1)
    if marg is not None:
        a.axvline(marg, color="#c0392b", ls=(0, (4, 2)), lw=.8, zorder=1)
        a.text(marg - .015 * (xl[1] - xl[0]), ytot - .9, "noninferiority margin", color="#c0392b", fontsize=6.6, ha="right", va="bottom", rotation=90)
    a.set_xlim(*xl); a.set_xlabel(lab); a.grid(axis="x", **GRID)
    a.spines["left"].set_visible(False); a.tick_params(axis="y", length=0)
    a.annotate("", xy=(xl[0] + .04 * (xl[1] - xl[0]), -.95), xytext=(0, -.95), xycoords="data",
               arrowprops=dict(arrowstyle="-|>", lw=.6, color="#555555"), annotation_clip=False)
    a.text(xl[0] / 2, -1.05, "favors selected schedule", fontsize=6.6, color="#555555", ha="center", va="bottom")
ax[0].set_ylim(ytot - .2, -1.6)
ax[0].set_yticks(ypos); ax[0].set_yticklabels([("   " + r[1]) for r in rows])
for t_, r in zip(ax[0].get_yticklabels(), rows):
    if r[5]: t_.set_fontweight("bold")
for st, y0 in heads:
    ax[0].text(-0.02, y0, SNAME[st], transform=ax[0].get_yaxis_transform(), ha="right", va="center", fontsize=7.8,
               fontweight="bold", color=SCOL[st] if st != "spec" else "#2b6cb0")
fig.legend(handles=[Line2D([], [], marker="o", color="#2b6cb0", lw=1, ms=3.8, mec="white", label="held-out trial (95% interval)"),
                    Line2D([], [], marker="D", color="#111111", lw=1.3, ms=5, mec="white", label="pooled (size-weighted)"),
                    Line2D([], [], color="#c0392b", ls=(0, (4, 2)), lw=.8, label="noninferiority margin")],
           loc="lower center", ncol=3, frameon=False, bbox_to_anchor=(.55, -.06))
save(fig, "fig4_heldout")

# ======================= Figure 5 =======================
H = pd.read_csv(ROOT + "results/algorithms/hv_all_algorithms.csv")
FAM = [("Pareto dominance + density", "#2b6cb0", [("SPEA2", "SPEA2"), ("NSGA2", "NSGA-II"), ("SPEA2SDE", "SPEA2+SDE")]),
       ("Reference points / vectors", "#2f8f5b", [("NSGA3", "NSGA-III"), ("RVEA", "RVEA")]),
       ("Indicator-based", "#c27c0e", [("IBEA", "IBEA"), ("SMSEMOA", "SMS-EMOA")]),
       ("Front-geometry estimation", "#7d4e9e", [("AGEMOEA", "AGE-MOEA"), ("AGEMOEA2", "AGE-MOEA-II")])]
items, yy, y = [], [], 0
for fam, c, al in FAM:
    for code, lab in al: items.append((code, lab, c)); yy.append(y); y += 1
    y += .55
fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.6), sharey=True, gridspec_kw=dict(wspace=.07))
rng = np.random.default_rng(1)
for a, m, tt in zip(ax, ("hv_train", "hv_test"), ("Training cohorts", "Held-out trials")):
    ref = H[H.alg == "NSGA2"].groupby("fold")[m].median(); Dd = H.assign(d=(H[m] - H.fold.map(ref)) * 1e3)
    rnd = Dd[Dd.alg == "RANDOM"].d.median()
    for (code, lab, c), y0 in zip(items, yy):
        v = Dd[Dd.alg == code].d.values
        b = a.boxplot(v, positions=[y0], vert=False, widths=.58, showfliers=False, patch_artist=True,
                      medianprops=dict(color="#111111", lw=1.2), whiskerprops=dict(color=c, lw=.8),
                      capprops=dict(color=c, lw=.8), boxprops=dict(facecolor=c, edgecolor=c, alpha=.55, lw=.8))
        a.plot(np.mean(v), y0, "o", ms=2.6, color="white", mec="#222222", mew=.6, zorder=4)
    a.axvline(0, color="#777777", lw=.7, ls=(0, (3, 2)), zorder=1); a.grid(axis="x", **GRID)
    a.spines["left"].set_visible(False); a.tick_params(axis="y", length=0)
    a.set_title(tt, loc="left", fontsize=9, fontweight="bold")
    a.set_xlim(-1.1 if m == "hv_train" else -1.7, .45 if m == "hv_train" else .75)
    a.set_xlabel(r"$\Delta$ hypervolume vs. NSGA-II fold median ($\times10^{-3}$)")
    a.text(.02, .98, f"random search: median {rnd:+.1f}" + r"$\times10^{-3}$" + "\n(off scale, not shown)", transform=a.transAxes,
           ha="left", va="top", fontsize=6.8, color="#555555",
           bbox=dict(boxstyle="round,pad=.3", fc="white", ec="#cccccc", lw=.5))
    a.annotate("better", xy=(.98, 1.035), xytext=(.80, 1.035), xycoords="axes fraction", va="center",
               arrowprops=dict(arrowstyle="-|>", lw=.6, color="#666666"), fontsize=6.8, color="#666666", ha="right")
    tag(a, "ab"[ax.tolist().index(a)], x=-.03 if a is ax[1] else -.25, y=1.04)
ax[0].set_yticks(yy); ax[0].set_yticklabels([i[1] for i in items]); ax[0].set_ylim(max(yy) + .6, -.6)
fig.legend(handles=[Line2D([], [], color="#111111", lw=1.2, label="median"), Line2D([], [], marker="o", ls="", ms=2.6, mfc="white", mec="#222222", label="mean")] + [Patch(fc=c, ec=c, alpha=.55, label=f) for f, c, _ in FAM], loc="lower center", ncol=6,
           frameon=False, bbox_to_anchor=(.5, -.08), handlelength=1.2, columnspacing=1.0)
save(fig, "fig5_hv")
print("figures written to", FIG)
