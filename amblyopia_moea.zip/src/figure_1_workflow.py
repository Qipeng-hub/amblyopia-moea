"""Figure 1: study workflow with the key equations (symbols defined in Sections 2.2-2.6 and in the caption).
Each component = a small illustration + its key equation(s) + one or two lines of text.
Times New Roman; STIX (Times-compatible) math.  usage: python figure_1_workflow.py <out_dir>"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import plot_style  # registers Times New Roman
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

TICK = "#6B6B6B"
plt.rcParams.update({"font.family": "Times New Roman", "mathtext.fontset": "stix", "font.size": 11,
                     "axes.linewidth": 0.6, "axes.edgecolor": TICK, "xtick.color": TICK, "ytick.color": TICK,
                     "axes.labelcolor": "#3A3A3A"})

W, H = 32.0, 14.2
fig = plt.figure(figsize=(16, 7.1)); ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis("off")

C = {"a": "#264653", "b": "#2A9D8F", "c": "#3A86A8", "d": "#E07A2E", "e": "#C8553D"}
INK, SUB, BG, LINE = "#1F1F1F", "#4A4A4A", "#F4F5F6", "#D9DCDF"

from matplotlib.colors import to_rgb
def tint(c, a):
    """light version of colour c: a = share of the colour mixed into white"""
    r, g, b = to_rgb(c); return (1 - a + a * r, 1 - a + a * g, 1 - a + a * b)

def card(x, y, w, h, fc=BG):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.2", fc=fc, ec="none", zorder=0))

def topbar(x, ytop, w, c):
    ax.add_patch(FancyBboxPatch((x + 0.2, ytop - 0.1), w - 0.4, 0.1, boxstyle="round,pad=0,rounding_size=0.05", fc=c, ec="none", zorder=1))

def arrow(x0, y0, x1, y1, c="#9A9A9A", lw=1.5):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=15, lw=lw, color=c,
                                 shrinkA=0, shrinkB=0, zorder=5, capstyle="round"))

def inset(i, left=0.95, right=0.35, bottom=0.55, top=0.15):
    """identical plotting box in every card (left margin leaves room for tick labels)"""
    x = xs[i] + left; y = iy + bottom; w = cw - left - right; h = ih - bottom - top
    a = fig.add_axes([x / W, y / H, w / W, h / H])
    for s in ("top", "right"): a.spines[s].set_visible(False)
    a.tick_params(labelsize=8.5, length=2.2, pad=1.5, width=0.6)
    a.patch.set_alpha(0)
    return a

# ---------------- layout ----------------
top_y, top_h = 4.6, 9.3
cw, gap = 5.72, 0.6
x0 = (W - (5 * cw + 4 * gap)) / 2
xs = [x0 + i * (cw + gap) for i in range(5)]
keys = "abcde"
titles = ["Public trial data", "Trajectory model", "Simulator", "Optimization model", "Protocol selection"]
iy, ih = top_y + 4.15, 4.05          # illustration band
for i in range(5):
    x, c = xs[i], C[keys[i]]
    card(x, top_y, cw, top_h, fc=tint(c, 0.075))
    ax.add_patch(FancyBboxPatch((x + 0.2, top_y + top_h - 0.1), cw - 0.4, 0.1, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=c, ec="none", zorder=1))
    ax.add_patch(Circle((x + 0.62, top_y + top_h - 0.68), 0.3, fc=c, ec="none", zorder=2))
    ax.text(x + 0.62, top_y + top_h - 0.69, keys[i], fontsize=12, weight="bold", color="white", ha="center", va="center", zorder=3)
    ax.text(x + 1.15, top_y + top_h - 0.68, titles[i], fontsize=13.5, weight="bold", color=INK, va="center")
    ax.plot([x + 0.35, x + cw - 0.35], [iy - 0.05] * 2, color=tint(c, 0.3), lw=0.8, zorder=1)   # divider: picture | equations
for i in range(4):
    yy = iy + ih / 2
    arrow(xs[i] + cw + 0.08, yy, xs[i + 1] - 0.08, yy)

def eq(i, y, s, fs=12.5):
    ax.text(xs[i] + cw / 2, y, s, fontsize=fs, ha="center", va="center", color=INK)

def note(i, y, s, fs=10.6, c=SUB, dot=True, **kw):
    if dot: ax.add_patch(Circle((xs[i] + 0.42, y), 0.055, fc=C[keys[i]], ec="none"))
    ax.text(xs[i] + 0.6, y, s, fontsize=fs, color=c, va="center", **kw)

E1, E2, N1, N2, N3 = top_y + 3.45, top_y + 2.65, top_y + 1.75, top_y + 1.22, top_y + 0.69
rng = np.random.default_rng(3)
t = np.linspace(0, 40, 200)

# (a) trial sizes (Table 1)
a = inset(0, left=1.05)
trials = ["ATS5", "ATS13", "ATS15", "ATS16", "ATS1", "ATS2A", "ATS2B", "ATS3", "ATS6", "ATS10", "ATS12"]
n = [254, 146, 306, 125, 415, 167, 185, 242, 415, 96, 18]
role = ["main"] * 4 + ["aux"] * 6 + ["replay"]
cc = {"main": C["a"], "aux": "#94AEB9", "replay": "#C4C4C4"}
ypos = np.array([10.6, 9.6, 8.6, 7.6, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0, -0.6])   # gaps between roles
a.barh(ypos, n, color=[cc[r] for r in role], height=0.74)
for yv, nv in zip(ypos, n):
    a.text(nv + 8, yv, f"{nv}", fontsize=7.2, color=TICK, va="center")
a.set_yticks(ypos); a.set_yticklabels(trials, fontsize=7.6)
a.set_xlabel("children", fontsize=8.5, labelpad=1); a.set_xlim(0, 480); a.set_xticks([0, 200, 400])
a.spines["left"].set_visible(False); a.tick_params(axis="y", length=0)
for lab, col, yv in (("main", cc["main"], 9.1), ("auxiliary", cc["aux"], 3.5), ("replay", "#A0A0A0", -0.6)):
    a.text(478, yv, lab, color=col, fontsize=8.5, style="italic", ha="right", va="center")
eq(0, E1, r"$y_{ij}$: logMAR acuity of child $i$", fs=11.8)
eq(0, E2, r"at time $t_{ij}$ (weeks), chart $c(i,j)$", fs=11.8)
note(0, N1, "2,351 children, 8,875 VA values")
note(0, N2, "main trials: spectacles, patching, atropine")
note(0, N3, "auxiliary trials: population parameters")

# (b) trajectory model: three children with different time constants + noisy observations
b = inset(1)
for V0, G, tau, al in ((0.78, 0.46, 4, 1.0), (0.72, 0.36, 11, 0.7), (0.66, 0.26, 22, 0.45)):
    m = V0 - G * (1 - np.exp(-t / tau))
    b.plot(t, m, color=C["b"], lw=1.7, alpha=al, solid_capstyle="round")
    tk = np.array([0, 5, 10, 16, 22, 30, 38]); yk = V0 - G * (1 - np.exp(-tk / tau)) + rng.standard_t(4, tk.size) * 0.025
    b.plot(tk, yk, "o", ms=3.4, color=C["b"], alpha=al, mec="white", mew=0.5)
b.set_ylim(0.85, 0.22); b.set_xlim(-1, 41)
b.set_xlabel("weeks", fontsize=8.5, labelpad=1); b.set_ylabel("logMAR", fontsize=8.5, labelpad=1)
b.set_xticks([0, 20, 40]); b.set_yticks([0.3, 0.5, 0.7])
b.text(40, 0.25, r"fast $\tau$", fontsize=8.5, color=C["b"], ha="right", style="italic")
b.text(40, 0.535, r"slow $\tau$", fontsize=8.5, color=C["b"], alpha=0.6, ha="right", style="italic")
eq(1, E1, r"$y_{ij}=V_{0i}-G_i\,(1-e^{-t_{ij}/\tau_i})+\varepsilon_{ij}$")
eq(1, E2, r"$\varepsilon_{ij}\sim t_{4}\,(0,\ \sigma_{c(i,j)})$")
note(1, N1, "Bayesian mixed-effects model (NUTS)")
note(1, N2, "covariates, trial and child effects")
note(1, N3, "RQ1:", c=C["b"], weight="bold")
ax.annotate(" leave-one-trial-out prediction", xy=(1, 0.5), xycoords=ax.texts[-1], va="center", fontsize=10.6, color=C["b"])

# (c) simulator: one virtual child, visits, rounded observations, t*
cax = inset(2)
V0, G, tau = 0.7, 0.4, 7.0
mu = V0 - G * (1 - np.exp(-t / tau))
ts = tau * np.log(G * (1 - np.exp(-12 / tau)) / 0.1)
cax.axvspan(ts, 41, color=tint(C["e"], 0.10), lw=0, zorder=0)
cax.plot(t, mu, color=C["c"], lw=1.7, label=r"$\mu(t;\theta)$")
tk = np.arange(0, 41, 5); yk = np.round((V0 - G * (1 - np.exp(-tk / tau)) + rng.standard_t(4, tk.size) * 0.025) * 10) / 10
yk[0] = 0.7
cax.plot(tk, yk, "s", ms=3.6, color="white", mec=C["c"], mew=1.1, label=r"$y_k$")
cax.axvline(ts, color=C["e"], ls=(0, (3, 2)), lw=1.0)
cax.text(ts + 0.9, 0.80, r"$t^*$", color=C["e"], fontsize=11.5)
cax.text(30, 0.60, "plateau", color=C["e"], fontsize=8.5, style="italic", ha="center", alpha=0.85)
cax.set_ylim(0.85, 0.22); cax.set_xlim(-1, 41)
cax.set_xlabel("weeks", fontsize=8.5, labelpad=1); cax.set_ylabel("logMAR", fontsize=8.5, labelpad=1)
cax.set_xticks([0, 20, 40]); cax.set_yticks([0.3, 0.5, 0.7])
cax.legend(loc="lower right", fontsize=8.5, frameon=False, handlelength=1.4, borderaxespad=0.2, bbox_to_anchor=(1.0, 0.0))
eq(2, E1, r"$y_k=\mathrm{round}_{0.1}\,(\mu(t_k;\theta)+\varepsilon_k)$")
eq(2, E2, r"$t^{*}=\min\{t:\ \mu(t;\theta)-\mu(t+12;\theta)<0.1\}$", fs=11.2)
note(2, N1, r"$\theta=(V_0,G,\tau)\sim p(\theta\mid\mathcal{D})$")
note(2, N2, r"$n$ = 20,000 virtual children per cohort")
note(2, N3, r"follow-up horizon $H$ = 52 weeks")

# (d) optimization: schematic Pareto front with the comparator and the selected protocol
d = inset(3, left=0.75)
front = lambda u: 0.05 / (u + 0.05) + 0.03
P = rng.uniform(0, 1, (1100, 2)); P = P[P[:, 1] > front(P[:, 0]) + 0.04]
P = P[rng.random(len(P)) < np.clip(1.3 - (P[:, 1] - front(P[:, 0])) * 1.8, 0.04, 1)]
d.scatter(P[:, 0], P[:, 1], s=4.5, color="#C8CBCE", lw=0)
u = np.linspace(0.0, 0.98, 400); d.plot(u, front(u), color=C["d"], lw=1.0, alpha=0.5)
uu = np.linspace(0.0, 0.98, 26) ** 1.6; d.plot(uu, front(uu), "o", ms=3.4, color=C["d"], mec="white", mew=0.4)
xc = 0.62; d.plot(xc, front(0.16), "s", ms=6.5, color="#6E6E6E", mec="white", mew=0.6)
d.plot(0.16, front(0.16), "*", ms=12, color=C["e"], mec="white", mew=0.6, zorder=5)
d.annotate("", xy=(0.19, front(0.16)), xytext=(xc - 0.03, front(0.16)),
           arrowprops=dict(arrowstyle="-|>", color=C["e"], lw=0.9, mutation_scale=9))
d.text(xc + 0.05, front(0.16), r"$\mathbf{x}_0$", fontsize=10.5, color="#555555", va="center")
d.text(0.13, front(0.16) - 0.13, r"$\hat{\mathbf{x}}$", fontsize=10.5, color=C["e"], ha="center")
d.text(0.30, 0.025, "Pareto front", color=C["d"], fontsize=9, style="italic")
d.set_xlim(0, 1); d.set_ylim(0, 1); d.set_xticks([]); d.set_yticks([])
d.set_xlabel(r"$f_1$ (visits)", fontsize=9, labelpad=2); d.set_ylabel(r"$f_2$ or $f_3$", fontsize=9, labelpad=2)
eq(3, E1, r"$\mathbf{x}=(d_1,\ldots,d_6,L,m,T_{\min})\in\mathcal{X}$", fs=12)
eq(3, E2, r"$\min_{\mathbf{x}\in\mathcal{X}}\ (f_1,\,f_2,\,f_3)$")
note(3, N1, r"$f_1=\mathbb{E}[N]$,  $f_2=\mathbb{E}[(S-t^{*})^{+}]$")
note(3, N2, r"$f_3=\Pr(R=1,\ S<t^{*})$")
note(3, N3, "solved by nine MOEAs")

# (e) selection: visit timelines, comparator vs selected
e = inset(4, left=0.35)
for yy, vis, col, lab in ((1.0, list(range(5, 41, 5)), "#7A7A7A", r"comparator $\mathbf{x}_0$: every 5 weeks"),
                          (0.0, [14, 22], C["e"], r"selected $\hat{\mathbf{x}}$")):
    e.hlines(yy, 0, 40, color="#C9C9C9", lw=1.2, capstyle="round")
    e.plot([0], [yy], "o", ms=4, color=col, mec="white", mew=0.5)
    e.plot(vis, [yy] * len(vis), "v", ms=8.5, color=col, mec="white", mew=0.5)
    e.text(0, yy + 0.36, lab, fontsize=9.8, color=col, va="center")
e.annotate("", xy=(22, -0.22), xytext=(14, -0.22), arrowprops=dict(arrowstyle="-|>", color=C["e"], lw=0.8, mutation_scale=8))
e.text(18, -0.48, "if \u2265 2-line gain", fontsize=8.5, color=C["e"], style="italic", ha="center", va="center")
e.set_ylim(-0.8, 1.65); e.set_xlim(-1, 41); e.set_yticks([]); e.spines["left"].set_visible(False)
e.set_xticks([0, 10, 20, 30, 40]); e.set_xlabel("weeks since start of treatment", fontsize=8.5, labelpad=1)
eq(4, E1, r"$\hat{\mathbf{x}}=\arg\min_{\mathbf{x}}\ f_1(\mathbf{x})$")
eq(4, E2, r"s.t. $f_2(\mathbf{x})\leq f_2(\mathbf{x}_0),\ f_3(\mathbf{x})\leq f_3(\mathbf{x}_0)$", fs=11.2)
note(4, N1, r"$\varepsilon$-constraint rule on the training cohort")
note(4, N2, r"$\mathbf{x}_0=(5,\ldots,5,\,1,\,2,\,0)$: PEDIG-style")
note(4, N3, "fewest visits, no worse on delay or safety")

# ---------------- bottom band: analyses ----------------
by, bh = 0.3, 3.85
lw_ = 17.6
card(x0, by, lw_, bh, fc=tint(C["a"], 0.075)); topbar(x0, by + bh, lw_, C["a"])
ax.add_patch(Circle((x0 + 0.62, by + bh - 0.55), 0.3, fc=C["a"], ec="none", zorder=2))
ax.text(x0 + 0.62, by + bh - 0.56, "f", fontsize=12, weight="bold", color="white", ha="center", va="center", zorder=3)
ax.text(x0 + 1.15, by + bh - 0.55, "Primary analysis (RQ2): leave-one-trial-out evaluation", fontsize=13.5, weight="bold", color=INK, va="center")
steps = [("1", "fit model", "without trial $k$", C["b"]), ("2", "optimize", "30 seeds", C["d"]),
         ("3", "select $\\hat{\\mathbf{x}}$", "\u03b5-constraint rule", C["e"]), ("4", "evaluate", "cohorts calibrated to trial $k$", C["c"])]
sw, sg = 3.72, 0.55
sx = x0 + 0.35
for j, (num, h1, h2, col) in enumerate(steps):
    xx = sx + j * (sw + sg)
    ax.add_patch(FancyBboxPatch((xx, by + 1.2), sw, 1.35, boxstyle="round,pad=0,rounding_size=0.16", fc="white", ec=col, lw=1.1))
    ax.add_patch(FancyBboxPatch((xx, by + 1.2), 0.12, 1.35, boxstyle="round,pad=0,rounding_size=0.05", fc=col, ec="none"))
    ax.text(xx + sw / 2 + 0.06, by + 2.08, h1, ha="center", va="center", fontsize=12, weight="bold", color=col)
    ax.text(xx + sw / 2 + 0.06, by + 1.6, h2, ha="center", va="center", fontsize=10.2, color=SUB)
    if j < 3: arrow(xx + sw + 0.07, by + 1.87, xx + sw + sg - 0.07, by + 1.87)
ax.text(x0 + 0.35, by + 0.58, "Met if the upper 95% limits satisfy:  \u0394visits < 0,  \u0394delay < 2 weeks,  \u0394premature stop < 3 percentage points",
        fontsize=10.6, color=SUB, va="center")

rx = x0 + lw_ + gap; rw = xs[4] + cw - rx
card(rx, by, rw, bh, fc=tint(C["d"], 0.075)); topbar(rx, by + bh, rw, C["d"])
ax.add_patch(Circle((rx + 0.62, by + bh - 0.55), 0.3, fc=C["d"], ec="none", zorder=2))
ax.text(rx + 0.62, by + bh - 0.56, "g", fontsize=12, weight="bold", color="white", ha="center", va="center", zorder=3)
ax.text(rx + 1.15, by + bh - 0.55, "Secondary analyses", fontsize=13.5, weight="bold", color=INK, va="center")
rows = [("RQ3", "nine MOEAs vs. random search and a schedule grid"),
        ("RQ4", "adaptive schedules"),
        ("Strata", "spectacles vs. patching or atropine"),
        ("Sensitivity", "noise, plateau threshold, horizon, auxiliary data"),
        ("Replay", "schedules applied to observed trajectories")]
yy = by + bh - 1.2
for lab, txt in rows:
    ax.text(rx + 0.35, yy, lab, fontsize=10.6, weight="bold", color=C["d"] if lab.startswith("RQ") else C["b"], va="center")
    ax.text(rx + 2.25, yy, txt, fontsize=10.6, color=SUB, va="center"); yy -= 0.5

OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "."; os.makedirs(OUTDIR, exist_ok=True)
fig.savefig(os.path.join(OUTDIR, "fig1_pipeline.png"), dpi=300, bbox_inches="tight", pad_inches=0.05, facecolor="white"); print("ok")
